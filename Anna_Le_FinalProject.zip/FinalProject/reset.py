import tkinter as tk 
from tkinter import messagebox as msg
from login_data import loginData
import tkmacosx as tkm

#handle reset password
class Reset:
    def checkCode(self):
        #check if backup code is correct
        value = self.code_entry.get()
        if loginData.compareCode(value):
            msg.showinfo("Show password", f"Your password is: {loginData.getPassword()}. Please save it and back to login again!")
            self.code_entry.delete(0, 'end')
        elif value.isalpha() == True:
            msg.showerror("Failed", "Your backup code must be numeric!")
            self.code_entry.delete(0, 'end')
        elif not value:
            msg.showerror("Failed", "Please enter your backup code!")
            self.code_entry.delete(0, 'end')
        else:
            msg.showerror("Failed", "Please check your backup code again!")
            self.code_entry.delete(0, 'end')


    def drawUI(self, screen, backToLogin):
        self.screen = screen
        self.frm = tk.Frame(screen, background="gold")
        self.frm.grid(row=0, column=0, sticky='news')
        self.backToLogin = backToLogin
        code_label = tk.Label(self.frm, text="Enter your backup code")
        code_label.grid(row=0, column=0, padx=10, pady=(50,0))
        text_label = tk.Label(self.frm, text="(4 digits numbers)")
        text_label.grid(row=1, column=0, pady=0)
        self.code_entry = tk.Entry(self.frm, show='*')
        self.code_entry.grid(row=0, column=1, columnspan=2, pady=(50,0))
        confirm_button = tkm.Button(self.frm, text="Confirm", command=self.checkCode, borderless=1)
        confirm_button.grid(row=1, column=1, pady=(10,5))
        login_button = tkm.Button(self.frm, text="Back to login", command=self.backToLogin, borderless=1)
        login_button.grid(row=2, column=1)
        

    def showUI(self):
        self.screen.title("Reset password")
        self.frm.tkraise()