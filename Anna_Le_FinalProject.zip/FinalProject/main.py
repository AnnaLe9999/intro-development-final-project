import tkinter as tk
import os
import firsttimelogin
import login
import reset
import initData
import dashboard
import transaction
import history
from login_data import loginData
import os
from budget_data import budgetData

#start application

def createDataDir():
    splittedFilePath = __file__.split('/')
    splittedFilePath.pop() #remove main.py
    dataDirPath = '/'.join(splittedFilePath) + '/data'
    if not os.path.exists(dataDirPath):
        os.mkdir(dataDirPath)

createDataDir()

#set up window
window = tk.Tk()
window.geometry('400x250')
window.title("Log In")
window.config(background="floral white")
window.rowconfigure(0,weight=1)
window.columnconfigure(0, weight=1)


#create screens objects
firsttimelogin = firsttimelogin.FirstTimeLogIn()
initData = initData.InitData()
login = login.LogIn()
reset = reset.Reset()
dashboard = dashboard.Dashboard(screen=window)
transaction = transaction.Transaction()
history = history.History()

#draw UI screens
firsttimelogin.drawUI(screen=window, openInitData=initData.showUI)
reset.drawUI(screen=window, backToLogin=login.showUI)
history.drawUI(screen=window, toDashboard=lambda: dashboard.showUI(onBackInitData=initData.showUI, toTransaction=transaction.showUI, toTranHis=history.showUI))
transaction.drawUI(screen=window, toDashboard=lambda: dashboard.showUI(onBackInitData=initData.showUI, toTransaction=transaction.showUI, toTranHis=history.showUI), toTranHistory=history.showUI)

def onLogin():
    if budgetData.hasBudgetSetup():
        dashboard.showUI(onBackInitData=initData.showUI, toTransaction=transaction.showUI, toTranHis=history.showUI)
    else:
        initData.showUI()

login.drawUI(screen=window, onLogIn=onLogin, onReSet=reset.showUI)
initData.drawUI(screen=window, openDashboard=lambda: dashboard.showUI(onBackInitData=initData.showUI, toTransaction=transaction.showUI, toTranHis=history.showUI))

#check if first time log in or not
if loginData.hasPassword():
    login.showUI()
else:
    firsttimelogin.showUI()


window.mainloop()