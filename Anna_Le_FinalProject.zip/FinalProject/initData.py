import tkinter as tk
from tkinter import messagebox as msg
from budget_data import budgetData
import tkmacosx as tkm

#collect initial data from user, allow user edit when needed
class InitData:

    entries_text = {}
    entries = {}

    def drawUI(self, screen, openDashboard):
        self.openDashboard = openDashboard
        self.screen = screen
        self.frm = tk.Frame(self.screen, bg='white')
        self.frm.grid(row=0, column=0, sticky="nsew", padx=10, pady=(15,15))
        
        tk.Label(self.frm, text="Enter budget a month", bg='white').grid(row=0, column=0, padx=(0,10))
        self.budget_entry_text = tk.StringVar()
        self.budget_entry = tk.Entry(self.frm, textvariable=self.budget_entry_text)
        self.budget_entry.grid(row=0, column=1)
        tk.Label(self.frm, text="$", bg='white').grid(row=0, column=3, padx=5, sticky="E")
        tk.Label(self.frm, text="(Example: 2500)", bg='white').grid(row=1, column=0)
        tk.Label(self.frm, text="Categories of purchases:", bg='white').grid(row=2, columnspan=2, pady=(20,0))

        row = 3
        for cate in budgetData.categories:
            tk.Label(self.frm, text=cate['name'], bg="white").grid(row=row, column=0, pady=(10,0), sticky='W')
            entry_text = tk.StringVar()
            entry = tk.Entry(self.frm, textvariable=entry_text)
            entry.grid(row=row, column=1, pady=(10,0))

            self.entries[cate['name']] = entry
            self.entries_text[cate['name']] = entry_text
            
            tk.Label(self.frm, text="$", bg='white').grid(row=row, column=3, padx=5, sticky="E")
            tk.Label(self.frm, text=cate['example'], fg='grey', bg='white').grid(row=row + 1, column=0, columnspan=2, sticky="w")
            row += 2

        save_button = tkm.Button(self.frm, text="Save & continue", command=self.saveButton, borderless=1)
        save_button.grid(row=13, columnspan=3, pady=(20,0))
    
    def showUI(self):
        self.fillOriginalValuesToEntries()
        self.screen.geometry('400x490')
        self.screen.title("Budget Control: Initial Data")
        self.frm.tkraise()

    def fillOriginalValuesToEntries(self):
        budgetList = budgetData.getBudgetList()
        totalBudget = budgetData.getTotalBudget()
        self.budget_entry_text.set(totalBudget)
        for key, entry_text in self.entries_text.items():
            if key in budgetList:
                entry_text.set(budgetList[key])

    def saveButton(self):
        budget_value = self.budget_entry.get()

        #amount of category must be >= 0
        isInt = True
        sumAmountCategory = 0
        for value in self.entries.values():
            if not value.get().isdigit():
                value.delete(0, 'end')
                isInt = False 
            else: 
                sumAmountCategory += int(value.get())
        if isInt == False:
            msg.showerror("Failed", "Amount of category must be an integer number.")

        #budget must be > 0
        if budget_value.isdigit():
            if int(budget_value) == 0:
                msg.showerror("Failed", "Amount of budget must be greater than 0")
                self.budget_entry.delete(0, 'end')
            else: 
                if sumAmountCategory == int(budget_value):
                    data = {}
                    for key, entry  in self.entries.items():
                        data[key] = int(entry.get())
                    budgetData.update(data)

                    #open Dashboard
                    self.openDashboard()
                    
                else:
                    differnce = int(budget_value) - sumAmountCategory
                    msg.showerror("Failed", f"Total amount of categories must be equal to amount of bugdet. Now, Budget = {differnce} + Categories.")
        else:
            msg.showerror("Failed", "Amount of budget must be an integer number.")
            self.budget_entry.delete(0, 'end')
    
        

        

       

        
            
            