How to run the app:

1. pip3 install tkinter tkmacosx json matplotlib
2. run app: main.py
3. See demo video for more informations.
