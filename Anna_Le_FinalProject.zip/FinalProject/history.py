import tkinter as tk
from tkinter import ttk
from transaction_data_processor import transDataProcessor
import tkmacosx as tkm

#show transactions history
class History:
    tranList = []
    def drawUI(self, screen, toDashboard):
        self.screen = screen
        self.toDashboard = toDashboard
        self.frm = tk.Frame(self.screen, background='white')
        self.frm.grid(row=0, column=0, sticky='news')

        # dropdown list and button
        tkm.Button(self.frm, text="Back to Dashboard", command=self.toDashboard, borderless=1).grid(row=0, column=0, pady=(10,0),padx=(20,0), sticky='w')
        tkm.Button(self.frm, text="Quit", command=self.quit, borderless=1).grid(row=0, column=3,pady=(10, 0), sticky='e')


        tk.Label(self.frm, text="Choose category:", background='white').grid(row=1, column=0, padx=(60,10), pady=(10,20))
        self.categoryList = ["Must have", "Children", "Entertainment", "Beauty", "Other"]
        self.combo = ttk.Combobox(self.frm, state='readonly',values=self.categoryList, width=10)
        self.combo.grid(row=1, column=1, pady=(10,20))
        self.combo.bind("<<ComboboxSelected>>", self.changeSelection)


    def showUI(self):
        self.screen.geometry("400x450")
        self.screen.title("Budget Control: Transactions History")
        self.frm.tkraise()

    def changeSelection(self, event):
        for label in self.tranList:
            label.destroy()
            self.tranList = []

        self.selection = self.combo.get()
        self.showTrans()

    def showTrans(self):
        for category in self.categoryList:
            if self.selection == category:
                try:
                    trans = transDataProcessor.data[self.selection]
                    i = 4
                    for tran in trans:
                        label = tk.Label(self.frm, text=f"{tran['name']}: ${tran['amount']}", background="white")
                        label.grid(row=i, column=0, padx=50, columnspan=2)
                        self.tranList.append(label)
                        i += 1
                except:
                    pass

    def quit(self):
        exit()
        