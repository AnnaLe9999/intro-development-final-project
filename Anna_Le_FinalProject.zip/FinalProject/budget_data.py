
import json

dir_path = __file__.split("/")
dir_path.pop()
budget_file = '/'.join(dir_path) + '/data/budget.json'

#handle budget json data, create, update budget list to this file
class BudgetData:
    categories = [
        {
            "name": "Must have",
            "amount": 0,
            "example": "(mortgage, insurance, utilities, food, gas,...)"
        },
        {
            "name": "Children",
            "amount": 0,
            "example": "(daycare, diapers, toys, study,...)",
        },
        {
            "name": "Entertainment",
            "amount": 0,
            "example": "(restaurant, activities, movies, party,...)"
        },
        {
            "name": "Beauty",
            "amount": 0,
            "example": "(hair, nails, skincare, shopping...)"
        },
        {
            "name": "Other",
            "amount": 0,
            "example": "(wedding, birthday, doctor visit,..)"
        },
    ]

    def __init__(self):
        self.loadData()
       
    def loadData(self):
        try:
            fi = open(budget_file, 'r')
            content = fi.read()
            fi.close()
            self.budget = json.loads(content)
        except:
            self.budget = {}
    
    def getTotalBudget(self):
        budget = 0
        for value in self.budget.values():
            budget += int(value)

        return budget
    
    def getBudgetList(self):
        return self.budget
    
    def getCateBudget(self, cate):
        if cate in self.budget:
            return self.budget[cate]
        return 0
    
    def hasBudgetSetup(self):
        totalCaterogy=5
        return len(self.budget.keys()) == totalCaterogy
    
    def update(self, data):
        fi = open(budget_file, 'w')
        fi.write(json.dumps(data))
        fi.close()
    

budgetData = BudgetData()