import tkinter as tk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
from transaction_data_processor import transDataProcessor
from budget_data import budgetData
import tkmacosx as tkm

#show main part of the app: bar chart
#attached buttons to have more functions for the app
class Dashboard:
    isDraw = False
    def __init__(self, screen):
        self.screen = screen
        self.frm = tk.Frame(self.screen, pady=10, background='white')
        self.frm.grid(row=0, column=0, sticky='news')

    def updateTotalBudget(self):
        totalBudget = budgetData.getTotalBudget()
        if self.isDraw == True:
            self.top_label.config(text=f"BUDGET A MONTH = {totalBudget}")

    def drawUI(self):
        if not self.isDraw:
            totalBudget = budgetData.getTotalBudget()
            self.top_label = tk.Label(self.frm, text=f"BUDGET A MONTH = {totalBudget}", bg="floral white")
            self.top_label.pack(anchor='center')

            #draw buttons
            edit_button = tkm.Button(self.frm, text="Edit Initial Data", command=self.onBackInitData , borderless=1)
            edit_button.place(relx=0.05, rely=0.8)
            collect_button = tkm.Button(self.frm, text="Enter Transaction", command=self.toTransaction, borderless=1)
            collect_button.place(relx=0.05, rely=0.87)
            tkm.Button(self.frm, text="Transaction history",command=self.toTranHis, borderless=1).place(relx=0.55, rely=0.87)
        
        self.isDraw = True    

    def drawBarChart(self):
        #draw bar chart
        #define chart
        fig = plt.figure(figsize=(4,4), dpi=100)
        self.labels = list(budgetData.getBudgetList().keys())
        labelPosition = np.arange(len(self.labels))

        totalTransAmountList = list(transDataProcessor.getAllTotalTransAmount().values())
        budgets = list(budgetData.getBudgetList().values())
        #format the chart bar:
        plt.bar(labelPosition - 0.2, budgets, color='blue', width=0.4, alpha=0.7, label='Budget') 
        plt.bar(labelPosition + 0.2, totalTransAmountList, color='gold', width=0.4, alpha=0.7, label='Spent')
        plt.xticks(labelPosition, self.labels, fontsize=7, rotation=25, horizontalalignment='center') #place label of each bar
        plt.yticks([])
        plt.tight_layout(pad=1.5)
        plt.legend()
        fig.suptitle("Amount of category ($)", fontsize=9)
            
        #apply the values on top of each bar
        for index, valuePoint in enumerate(budgets):
            plt.text(x=index -0.2, y=valuePoint, s=f"{valuePoint}", fontdict=dict(fontsize=6), ha='center', va='bottom')
        
         #apply the values on top of each bar
        for index, valuePoint in enumerate(totalTransAmountList):
            plt.text(x=index + 0.2, y=valuePoint, s=f"{valuePoint}", fontdict=dict(fontsize=6), ha='center', va='bottom')
           
        canvasbar = FigureCanvasTkAgg(fig, master=self.frm)
        canvasbar.draw()
        canvasbar.get_tk_widget().place(relx=0.5, rely=0.42, anchor='center')
        plt.close(fig=fig)

    def showUI(self, onBackInitData, toTransaction, toTranHis):
        budgetData.loadData() # reload data
        self.updateTotalBudget()
        self.screen.geometry('400x600')
        self.screen.title("Budget Control: Dashboard")
        self.onBackInitData = onBackInitData
        self.toTransaction = toTransaction
        self.toTranHis = toTranHis

        # always draw ui because the chart needs to update after
        # user add new transactions 
        transDataProcessor.loadAllTransactions() # refresh data after user add transaction
        self.drawUI()
        self.drawBarChart()
        self.frm.tkraise()

        
        