import tkinter as tk
from tkinter import ttk
from tkinter import messagebox as msg
from transaction_data_processor import transDataProcessor
from budget_data import budgetData
import tkmacosx as tkm

#add transactions prompt from user
class Transaction:
    def drawUI(self, screen, toDashboard, toTranHistory):
        self.screen = screen
        self.frm = tk.Frame(self.screen, background="floral white")
        self.frm.grid(row=0, column=0, sticky='news')
        self.categoryList = ["Must have", "Children", "Entertainment", "Beauty", "Other"]
        tk.Label(self.frm, text='Enter transaction name:', bg='floral white').grid(row=0, column=0, padx=(30,10), pady=(50,10), sticky='e')
        self.transaction_name = tk.Entry(self.frm)
        self.transaction_name.grid(row=0, column=1, pady=(50,10))
        tk.Label(self.frm, text='Enter transaction amount:', bg='floral white').grid(row=1, column=0, padx=10, pady=(0,10), sticky='e')
        self.transaction_amount = tk.Entry(self.frm)
        self.transaction_amount.grid(row=1, column=1, pady=(0,10))
        tk.Label(self.frm, text="Choose category: ", bg='floral white').grid(row=2, column=0)
        self.combo = ttk.Combobox(self.frm, state='readonly', values=self.categoryList, width=10)
        self.combo.grid(row=2, column=1)

        tkm.Button(self.frm, text="Save Transaction", command=self.saveTransaction, borderless=1).grid(row=3, column=1, pady=(20,10),)
        tkm.Button(self.frm, text="Go to Dashboard", command=toDashboard, borderless=1).grid(row=3, column=0, pady=(20,10))
        tkm.Button(self.frm, text="Transaction History",command=toTranHistory, borderless=1).grid(row=4, column=0,)


    def showUI(self):
        self.screen.geometry("400x300")
        self.screen.title("Budget Control: Transactions")
        self.frm.tkraise()

    def saveTransaction(self):
        entryName = self.transaction_name.get()
        entryAmount = self.transaction_amount.get()
        entryCategory = self.combo.get()
        isAmountValid = False
        try:
            float(entryAmount)
            isAmountValid = True
        except ValueError:
            msg.showerror("Failed", "Transaction amount must be a numeric.")
            self.transaction_amount.delete(0, 'end')

        if isAmountValid == True and entryCategory != '' and entryName != '':
            totalSpent = transDataProcessor.getTotalTransAmount(entryCategory)
            if totalSpent + float(entryAmount) <= budgetData.getCateBudget(entryCategory) * 2:
                msg.showinfo("Success!", "Success! Your data is saved.")
                self.transaction_name.delete(0, 'end')
                self.transaction_amount.delete(0, 'end')
                self.combo.set('')

                newTran = {"name": entryName, "amount": float(entryAmount)}
                transDataProcessor.addTransaction(cate=entryCategory, newTran=newTran)
            else: 
                msg.showerror("Oh no", "Your transaction amount is over 100% your category budget! Please check your amount again.")

        if entryName == '':
            msg.showerror("Failed", "You must enter transaction name.")
        if entryCategory == '':
            msg.showerror("Failed", "You must choose category.")
        
