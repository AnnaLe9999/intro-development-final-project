from tkinter import *
from tkinter import messagebox as msg
from login_data import loginData
import tkmacosx as tkm

#for the first time log in, collect password and backup code from user
class FirstTimeLogIn:
    #button
    def logInFt(self):
        entryValuePass = self.password_entry.get()
        entryValueCode = self.code_entry.get()

        if entryValuePass.isdigit() and len(entryValuePass) == 5 and entryValueCode.isdigit() and len(entryValueCode) == 4:
            msg.showinfo("Success", "Congratulation! Log in successfully!")
            #convert object into json str
            loginData.save(password=entryValuePass, code=entryValueCode)

            #open InitData
            self.openInitData()
        else:
            msg.showerror("Failed", "Check your password or your backup code again please!")

    #UI
    def drawUI(self, screen, openInitData):
        self.openInitData = openInitData
        #create frame
        self.frm = Frame(screen)
        self.frm.grid(row=0, column=0, sticky='news')
        #enter password
        password_label = Label(self.frm, text='Enter password')
        password_label.grid(row=0, column=0, padx=(20,0), pady=(20,0))
        self.password_entry = Entry(self.frm, show='*')
        self.password_entry.grid(row=0, column=1, pady=(20,0))
        sub_label = Label(self.frm, text='(Your password must be 5 digits)')
        sub_label.grid(row=1, column=1)
        #backup code
        code_label = Label(self.frm, text='Backup code')
        code_label.grid(row=2, column=0, pady=(20,0))
        self.code_entry = Entry(self.frm, show='*')
        self.code_entry.grid(row=2, column=1, pady=(20,0))
        sub2_label = Label(self.frm, text='(Your code must be 4 digits)')
        sub2_label.grid(row=3, column=1)
        sub3_label = Label(self.frm, text='This is used for recovering your password.')
        sub3_label.grid(row=4, column=1)
        #log in button
        login_button = tkm.Button(self.frm, text='Log in', command=self.logInFt, borderless=1)
        login_button.grid(row=5, column=1, pady=20)

    def showUI(self):
        self.frm.tkraise()