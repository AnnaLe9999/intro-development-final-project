from tkinter import *
from tkinter import messagebox as msg
from login_data import loginData
import tkmacosx as tkm

#for the first time log in, collect password and backup code from user
class FirstTimeLogIn:
    #button
    def logInFt(self):
        entryValuePass = self.password_entry.get()
        entryValueCode = self.code_entry.get()
        reentryValuePass = self.password_reentry.get()
        reentryValueCode = self.code_reentry.get()

        if entryValuePass.isdigit() and len(entryValuePass) == 5 and entryValueCode.isdigit() and len(entryValueCode) == 4 and entryValuePass == reentryValuePass and entryValueCode == reentryValueCode:
            msg.showinfo("Success", "Congratulation! Log in successfully!")
            #convert object into json str
            loginData.save(password=entryValuePass, code=entryValueCode)
            #open InitData
            self.openInitData()
        elif not entryValuePass.isdigit() or len(entryValuePass) != 5:
            msg.showerror("Failed", "Check your password again please!")
            self.password_entry.delete(0, 'end')
            self.password_reentry.delete(0, 'end')
        elif entryValuePass != reentryValuePass:
            msg.showerror("Failed", "Check your re-enter password again please!")
            self.password_reentry.delete(0, 'end')
        elif not entryValueCode.isdigit() or len(entryValueCode) != 4:
            msg.showerror("Failed", "Check your backup code again please!")
            self.code_entry.delete(0, 'end')
            self.code_reentry.delete(0, 'end')
        elif entryValueCode != reentryValueCode:
            msg.showerror("Failed", "Check your re-enter backup code again please!")
            self.code_reentry.delete(0, 'end')

    #UI
    def drawUI(self, screen, openInitData):
        self.openInitData = openInitData
        #create frame
        self.frm = Frame(screen)
        self.frm.grid(row=0, column=0, sticky='news')

        #password
        Label(self.frm, text='Enter password').grid(row=0, column=0, padx=(20,0), pady=(20,0))
        self.password_entry = Entry(self.frm, show='*')
        self.password_entry.grid(row=0, column=1, pady=(20,0))
        sub_label = Label(self.frm, text='(Your password must be 5 digits)', fg='grey')
        sub_label.grid(row=1, column=0)
        Label(self.frm, text='Re-enter password').grid(row=2, column=0, padx=(20,0), pady=(0,10))
        self.password_reentry = Entry(self.frm, show='*')
        self.password_reentry.grid(row=2, column=1, pady=(0,10))

        #backup code
        Label(self.frm, text='Backup code').grid(row=3, column=0, pady=(20,0))
        self.code_entry = Entry(self.frm, show='*')
        self.code_entry.grid(row=3, column=1, pady=(20,0))
        sub2_label = Label(self.frm, text='(Your code must be 4 digits)', fg='grey')
        sub2_label.grid(row=4, column=0)
        Label(self.frm, text="Re-enter backup code").grid(row=5, column=0)
        self.code_reentry = Entry(self.frm, show='*')
        self.code_reentry.grid(row=5, column=1)
        sub3_label = Label(self.frm, text='This is used for recovering your password.', fg='grey')
        sub3_label.grid(row=6, column=1)

        #log in button
        login_button = tkm.Button(self.frm, text='Log in', command=self.logInFt, borderless=1)
        login_button.grid(row=7, column=1, pady=20)

    def showUI(self):
        self.frm.tkraise()