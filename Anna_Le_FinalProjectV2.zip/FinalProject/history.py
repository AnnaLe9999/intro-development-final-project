import tkinter as tk
from tkinter import ttk
from transaction_data_processor import transDataProcessor
import tkmacosx as tkm
from tkinter import messagebox as msg

#show transactions history
class History:
    tranList = []
    allTransLabelsList = []
    def drawUI(self, screen, toDashboard):
        self.screen = screen
        self.toDashboard = toDashboard
        self.frm = tk.Frame(self.screen, background='white')
        self.frm.grid(row=0, column=0, sticky='news')

        # dropdown list and button
        tkm.Button(self.frm, text="Back to Dashboard", command=self.toDashboard, borderless=1).grid(row=0, column=0, columnspan=4, pady=(20,0))

        tk.Label(self.frm, text="See transactions of current month:", bg="azure", fg='blue').grid(row=1, column=0, columnspan=2, pady=(20,0))
        tk.Label(self.frm, text="Choose category:", background='white smoke').grid(row=2, column=0, padx=(10,10), pady=(10,0))
        self.categoryList = ["Must have", "Children", "Entertainment", "Beauty", "Other"]
        self.combo = ttk.Combobox(self.frm, state='readonly',values=self.categoryList, width=10)
        self.combo.grid(row=2, column=1, pady=(10,0))
        self.combo.bind("<<ComboboxSelected>>", self.changeSelection)

        tk.Label(self.frm, text="See all transactions of the month/year:", bg="azure", fg='blue').grid(row=1, column=2,columnspan=2, pady=(20,0), padx=(30,0))
        tk.Label(self.frm, text="Enter month/year:", background='white smoke').grid(row=2, column=2, padx=(30,10), pady=(10,0))
        self.entry = tk.Entry(self.frm, width=10)
        self.entry.grid(row=2, column=3, pady=(10,0))
        tk.Label(self.frm, text="Format: mm/yyyy", fg='grey', bg='white').grid(row=4, column=3, pady=(0, 0))
        tkm.Button(self.frm, text="Submit", command=self.submit, borderless=1).grid(row=5, column=3, pady=5)

    def showUI(self):
        self.clearInfoUI()
        self.screen.geometry("550x700")
        self.screen.title("Budget Control: Transactions and Budgets History")
        self.frm.tkraise()

    def changeSelection(self, event):
        for label in self.tranList:
            label.destroy()
            self.tranList = []

        self.selection = self.combo.get()
        self.showTrans()

    #show transactions of each category of current month
    def showTrans(self):
        for category in self.categoryList:
            if self.selection == category:
                try:
                    transactions = transDataProcessor.trans[self.selection]
                    i = 6
                    for tran in transactions:
                        label = tk.Label(self.frm, text=f"{tran['name']}: ${tran['amount']}", background="white")
                        label.grid(row=i, column=0, sticky='e')
                        self.tranList.append(label)
                        i += 1
                except:
                    pass

    def submit(self):
        self.removeAllLabels()
        dateEntry = self.entry.get()
        if '/' not in dateEntry or len(dateEntry) != 7:
            msg.showerror("Failed", "You must enter a right format month/year data.") 
            self.entry.delete(0, 'end')
        else:   
            split_date = dateEntry.split('/')
            month = split_date[0]
            year = split_date[1]
            if not month.isdigit() or len(month) != 2 or int(month) < 1 or int(month) > 12:
                msg.showerror("Failed", "Month must be a numeric from 01 to 12.")
                self.entry.delete(0, 'end')
            if not year.isdigit() or len(year) != 4 or int(year) < 2024 or int(year) > 2025:
                msg.showerror("Failed", "Year must be a numeric from 2024 to 2025.")
                self.entry.delete(0, 'end')
            else: 
                #show all transactions of month user input
                if dateEntry in transDataProcessor.data:
                    cateTrans = transDataProcessor.data[dateEntry]
                    i = 6
                    for cate, transList in cateTrans.items():
                        label = tk.Label(self.frm, text=f"{cate}: ", background="white")
                        label.grid(row=i, column=2,padx=(30,10), sticky='w')
                        i += 1
                        self.allTransLabelsList.append(label)
                        for tran in transList: #trans = {}
                            label = tk.Label(self.frm, text=f"{tran['name']}: ${tran['amount']}", background="white")
                            label.grid(row=i, column=2, columnspan=2, sticky='e')
                            self.allTransLabelsList.append(label)
                            i += 1
                        
                else:
                    msg.showerror("Failed", "The month/year you entered does have data. Plese enter a valid data again.")
                    self.entry.delete(0, 'end')

    #clear all transactions on screen          
    def clearInfoUI(self):
        self.combo.set('')
        for label in self.tranList:
            label.destroy()
        self.tranList = []
        self.removeAllLabels()
        self.entry.delete(0, 'end')
    
    #remove all transactions history on right column
    def removeAllLabels(self):
        for label in self.allTransLabelsList:
            label.destroy()
        self.allTransLabelsList = []