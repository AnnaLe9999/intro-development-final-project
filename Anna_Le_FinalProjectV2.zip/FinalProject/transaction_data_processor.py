import json
from budget_data import budgetData

dir_path = __file__.split("/")
dir_path.pop()
file_path = '/'.join(dir_path) + "/data/transactions.json"

#handle transactions data
class TransactionData:
    def __init__(self):
        self.loadAllTransactions()

    def loadAllTransactions(self):
        try:
            fi = open(file_path, 'r')
            content = fi.read()
            fi.close()
            self.data = json.loads(content)
            activeMonthValue = budgetData.activeMonth
            self.trans = self.data.get(activeMonthValue, {})
        except:
            self.data = {}
            self.trans = {}

    # sum of amount of all transaction of a input category -> a number
    def getTotalTransAmount(self, cate):
        totalAmount = 0
        if cate in self.trans:
            for tran in self.trans[cate]:
                totalAmount += tran['amount']
        return totalAmount
    
    # calculate total amount of all transactions in each category -> dictionary
    def getSpentAmountOfEachCate(self):
        allTotalAmount = {}
        for cate in budgetData.getBudgetData().keys():
            allTotalAmount[cate] = self.getTotalTransAmount(cate)
        return allTotalAmount
    

    def addTransaction(self, cate, newTran, date):
        fi = open(file_path, 'w')
        if date not in self.data:
            self.data[date] = self.trans
       
        if cate not in self.trans:
            self.trans[cate] = []

        self.trans[cate].append(newTran)
        fi.write(json.dumps(self.data))
        fi.close()




transDataProcessor = TransactionData()