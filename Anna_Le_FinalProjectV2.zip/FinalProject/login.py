from tkinter import *
from tkinter import messagebox as msg
from login_data import loginData
import tkmacosx as tkm

#show login screen when user already created password
class LogIn:
    def logIn(self):
        entryValuePass = self.access_entry.get()

        if loginData.comparePassword(entryValuePass):
            self.onLogIn()
        else:
            msg.showerror("Failed", "Please check your password again!")
            self.access_entry.delete(0, 'end')

    def drawUI(self, screen, onLogIn, onReSet):
        self.screen = screen
        self.onLogIn = onLogIn
        self.onReSet = onReSet
        #creat a frame
        self.frm = Frame(screen, background="old lace")
        self.frm.grid(row=0, column=0, sticky="nsew")
        #access password
        self.access_label = Label(self.frm, text="Access password", bg='white')
        self.access_label.grid(row=0, column=0, padx=20, pady=(60,20))
        #create entry
        self.access_entry = Entry(self.frm, show="*")
        self.access_entry.grid(row=0, column=1, pady=(60,15))
        #log in button
        self.login_button = tkm.Button(self.frm, text="Log in", command=self.logIn, borderless=1)
        self.login_button.grid(row=1, column=1)
        #reset button
        self.reset_button = tkm.Button(self.frm, text='Forgot password? Reset it', command=self.onReSet, borderless=1)
        self.reset_button.grid(row=2, column=1, pady=(10,0))

    def showUI(self):
        # self.screen.geometry("200x200")
        self.screen.title("Log In")
        self.screen.geometry("400x250")
        self.frm.tkraise()
        self.access_entry.delete(0, END)