import tkinter as tk
from tkinter import messagebox as msg
from budget_data import budgetData
import tkmacosx as tkm

#collect initial data from user, allow user edit when needed
class InitData:

    entries_text = {}
    entries = {}
    isStartNew = False

    def drawUI(self, screen, openDashboard):
        self.openDashboard = openDashboard
        self.screen = screen
        self.frm = tk.Frame(self.screen, bg='white')
        self.frm.grid(row=0, column=0, sticky="nsew")
        
        tk.Label(self.frm, text="Enter budget a month", bg='white').grid(row=0, column=0, padx=(20,10), pady=(20,0))
        self.budget_entry_text = tk.StringVar()
        self.budget_entry = tk.Entry(self.frm, textvariable=self.budget_entry_text)
        self.budget_entry.grid(row=0, column=1, pady=(20,0))
        tk.Label(self.frm, text="$", bg='white').grid(row=0, column=3, padx=(5,0), pady=(20,0), sticky="E")
        tk.Label(self.frm, text="(Example: 2500)", bg='white', fg='grey').grid(row=1, column=0)
        
        tk.Label(self.frm, text="Enter month/year", bg='white').grid(row=2, column=0, padx=(20,10), pady=(10,0))
        self.month_entry_text = tk.StringVar()
        self.month_entry = tk.Entry(self.frm, textvariable=self.month_entry_text)
        self.month_entry.grid(row=2, column=1, pady=(10,0))
        tk.Label(self.frm, text="$", bg='white').grid(row=2, column=3, padx=(5,0), pady=(10,0), sticky="E")
        tk.Label(self.frm, text="(Format: mm/yyyy)", bg='white', fg='grey').grid(row=3, column=1)

        tk.Label(self.frm, text="CATEGORIES OF PURCHASES", bg='white').grid(row=4, columnspan=2, pady=(20,0))
        

        row = 5
        for cate in budgetData.categories:
            tk.Label(self.frm, text=cate['name'], bg="white").grid(row=row, column=0, pady=(10,0), padx=(20,0), sticky='W')
            entry_text = tk.StringVar()
            self.entry = tk.Entry(self.frm, textvariable=entry_text)
            self.entry.grid(row=row, column=1, pady=(10,0))

            self.entries[cate['name']] = self.entry
            self.entries_text[cate['name']] = entry_text
            
            tk.Label(self.frm, text="$", bg='white').grid(row=row, column=3, padx=(5,0), pady=(10,0), sticky="E")
            tk.Label(self.frm, text=cate['example'], fg='grey', bg='white').grid(row=row + 1, column=0, columnspan=2, sticky="w")
            row += 2


        tkm.Button(self.frm, text="Save & continue", command=self.saveButton, borderless=1).grid(row=15, column=1, pady=(20,0), padx=10)
        tkm.Button(self.frm, text="Cancel", command=self.onCancel, borderless=1).grid(row=15, column=0, pady=(20,0), padx=10)
    
    def showUI(self):
        self.isStartNew = False
        self.fillOriginalValuesToEntries()
        self.month_entry_text.set(budgetData.getDate())
        self.month_entry.config(state='disabled')
        self.screen.geometry('400x550')
        self.screen.title("Budget Control: Initial Data")
        self.frm.tkraise()

    def startNewMonth(self):
        self.isStartNew = True
        self.screen.geometry('400x550')
        self.screen.title("Budget Control: Initial Data")
        self.budget_entry_text.set('')
        self.month_entry_text.set('')
        self.month_entry.config(state='normal')
        for entry_text in self.entries_text.values():
            entry_text.set('')
        self.frm.tkraise()

    def fillOriginalValuesToEntries(self):
        budgetList = budgetData.getBudgetData()
        totalBudget = budgetData.getTotalBudget()
        self.budget_entry_text.set(totalBudget)
        for key, entry_text in self.entries_text.items():
            if key in budgetList:
                entry_text.set(budgetList[key])

    def saveButton(self):
        budget_value = self.budget_entry.get()
        month_year = self.month_entry.get()

        #amount of category must be >= 0
        isInt = True
        sumAmountCategory = 0
        for value in self.entries.values():
            if not value.get().isdigit():
                value.delete(0, 'end')
                isInt = False 
            else: 
                sumAmountCategory += int(value.get())
        if isInt == False:
            msg.showerror("Failed", "Amount of category must be an integer number.")
        
        #valid format month/year: month - from 01 to 12, year - from 2024 to 2025
        isValidMonth = False
        if '/' not in month_year or len(month_year) != 7:
            msg.showerror("Failed", "You must enter a right format month/year data.") 
            self.month_entry.delete(0, 'end')
        else:   
            split_month_year = month_year.split('/')
            month = split_month_year[0]
            year = split_month_year[1]
            if not month.isdigit() or len(month) != 2 or int(month) < 1 or int(month) > 12:
                msg.showerror("Failed", "Month must be a numeric from 01 to 12.")
                self.month_entry.delete(0, 'end')
            if not year.isdigit() or len(year) != 4 or int(year) < 2024 or int(year) > 2025:
                msg.showerror("Failed", "Year must be a numeric from 2024 to 2025.")
                self.month_entry.delete(0, 'end')
            else: 
                isValidMonth = True

        #budget must be > 0
        if budget_value.isdigit():
            if int(budget_value) == 0:
                msg.showerror("Failed", "Amount of budget must be greater than 0")
                self.budget_entry.delete(0, 'end')
            else: 
                if sumAmountCategory == int(budget_value) and isValidMonth:
                    if self.isStartNew == False or (self.isStartNew == True and not budgetData.existDate(month_year)):
                        data = budgetData.data
                        budgets = {}
                        for key, entry  in self.entries.items():
                            budgets[key] = int(entry.get())
                        data[month_year] = budgets
                        data["active"] = month_year
                        budgetData.update(data)
                        msg.showinfo("Success", "Your data has been saved.")

                        #open Dashboard
                        self.openDashboard()
                        
                    elif self.isStartNew == True and budgetData.existDate(month_year):
                        msg.showerror("Failed", f"The month/year is alredy exist.")
                        self.month_entry.delete(0, 'end')

                if sumAmountCategory != int(budget_value):
                    differnce = int(budget_value) - sumAmountCategory
                    msg.showerror("Failed", f"Total amount of categories must be equal to amount of bugdet. Now, Budget = {differnce} + Categories.")
        else:
            msg.showerror("Failed", "Amount of budget must be an integer number.")
            self.budget_entry.delete(0, 'end')
    
    def onCancel(self):
        if budgetData.hasBudgetSetup():
            self.openDashboard()
        else:
            exit()

       

        
            
            