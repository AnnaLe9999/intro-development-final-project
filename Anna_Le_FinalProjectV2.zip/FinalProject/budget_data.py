
import json

#create budget.json file in folder data
dir_path = __file__.split("/")
dir_path.pop()
budget_file = '/'.join(dir_path) + '/data/budget.json'

#handle budget json data, create, update budget list to this file
class BudgetData:
    categories = [
        {
            "name": "Must have",
            "amount": 0,
            "example": "(mortgage, insurance, utilities, food, gas,...)"
        },
        {
            "name": "Children",
            "amount": 0,
            "example": "(daycare, diapers, toys, study,...)",
        },
        {
            "name": "Entertainment",
            "amount": 0,
            "example": "(restaurant, activities, movies, party,...)"
        },
        {
            "name": "Beauty",
            "amount": 0,
            "example": "(hair, nails, skincare, shopping...)"
        },
        {
            "name": "Other",
            "amount": 0,
            "example": "(wedding, birthday, doctor visit,..)"
        },
    ]

    def __init__(self):
        self.loadData()
       
    def loadData(self):
        try:
            fi = open(budget_file, 'r')
            content = fi.read()
            fi.close()
            self.data = json.loads(content)
            self.activeMonth = self.data["active"]
            self.budget = self.data[self.activeMonth]
        except:
            self.data = {}
            self.budget = {}

    #check if initial data is set up
    def hasBudgetSetup(self):
        totalCaterogy=5
        return len(self.budget.keys()) == totalCaterogy
    
    def getTotalBudget(self):
        budget = 0
        for value in self.budget.values():
            budget += int(value)
        return budget
    
    def getBudgetData(self):
        return self.budget
    
    def getEachCateBudget(self, cate):
        if cate in self.budget:
            return self.budget[cate]
        return 0
    
    def update(self, data):
        fi = open(budget_file, 'w')
        fi.write(json.dumps(data))
        fi.close()

    def getDate(self):
        try: 
            return self.activeMonth
        except:
            return ''
    
    def existDate(self, date):
        if date in self.data:
            return True
        return False

budgetData = BudgetData()