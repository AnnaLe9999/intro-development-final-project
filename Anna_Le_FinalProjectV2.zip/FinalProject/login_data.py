import json

dir_path = __file__.split("/")
dir_path.pop()
data_file_path = '/'.join(dir_path) + '/data/keyPass.json'

#store password and backup code to keyPass.json file
class LoginData:
    def __init__(self):
        self.loadData()

    #save data object if password and code valid 
    def save(self, password, code):
        fi = open(data_file_path, 'w')
        data = {"password": password, "code": code}
        fi.write(json.dumps(data))
        fi.close()

    def comparePassword(self, password):
        if "password" in self.data:
            return self.data['password'] == password
        return False
    
    def compareCode(self, code):
        if "code" in self.data:
            return self.data['code'] == code
        return False
    
    #check if key 'password' exists in data object
    def hasPassword(self):
        if "password" in self.data:
            return True
        return False
    
    def getPassword(self):
        if "password" in self.data:
            return self.data["password"]
        return ""
       
    def loadData(self):
        try:
            fi = open(data_file_path, 'r')
            content = fi.read()
            fi.close()
            self.data = json.loads(content)
        except:
            self.data = {}

    

    
loginData = LoginData()