from tkinter import *
from tkinter import ttk
from tkinter import messagebox as msg
import os
import json

#get file path
file_path = __file__.rstrip('main.py') + "keyPass.json"

#button
def logInFirstTime():
    entryValuePass = password_entry.get()
    entryValueCode = code_entry.get()
    data = {'password': entryValuePass, 'code': entryValueCode}
    if entryValuePass.isdigit() and len(entryValuePass) == 5 and entryValueCode.isdigit() and len(entryValueCode) == 4:
        msg.showinfo("Success", "Congratulation")
        data_json = json.dumps(data)
        #open a file (keyPass.txt) to save password and code
        file = open(file_path, 'w')
        file.write(data_json)
        file.close()
        #open dashboard
    else:
        msg.showerror("Failed", "Check your password or your backup code again please!")

def logIn():
    entryValuePass = access_entry.get()
    open_file = open(file_path, 'r')
    data = json.load(open_file)
    #print(type(data), data) 
    if entryValuePass.isdigit() and entryValuePass == data['password']:
        msg.showinfo("Success!", "Congratulation!")
    else:
        msg.showerror("Failed", "Please check your password again!")

def resetPass():
    #draw resetUI
    code_label = Label(home, text="Enter your backup code")
    code_label.grid(row=0, column=0, padx=10, pady=50)
    code_entry = Entry(home)
    code_entry.grid(row=0, column=1, pady=50)
    #check if backup code is correct
    pass

#drawUI if first time log in
def drawFirstTime():
    #enter password
    password_label = Label(home, text='Enter password')
    password_label.grid(row=0, column=0, padx=(20,0), pady=(20,0))
    global password_entry
    password_entry = Entry(home)
    password_entry.grid(row=0, column=1, pady=(20,0))
    sub_label = Label(home, text='(Your password must be 5 digits)')
    sub_label.grid(row=1, column=1)
    #backup code
    code_label = Label(home, text='Backup code')
    code_label.grid(row=2, column=0, pady=(20,0))
    global code_entry
    code_entry = Entry(home)
    code_entry.grid(row=2, column=1, pady=(20,0))
    sub2_label = Label(home, text='(Your code must be 4 digits)')
    sub2_label.grid(row=3, column=1)
    sub3_label = Label(home, text='This is used for recovering your password.')
    sub3_label.grid(row=4, column=1)
    #log in button
    login_button = Button(home, text='Log in', command=logInFirstTime)
    login_button.grid(row=5, column=1, pady=20)

#drawUI if already log in
def drawUI():
    #access password
    access_label = Label(home, text="Access password")
    access_label.grid(row=0, column=0, padx=20, pady=(60,20))
    global access_entry
    access_entry = Entry(home)
    access_entry.grid(row=0, column=1, pady=(60,15))
    #log in button
    login_button = Button(home, text="Log in", command=logIn)
    login_button.grid(row=1, column=1)
    #reset button
    reset_button = Button(home, text='Forgot password? Reset it', command=resetPass)
    reset_button.grid(row=2, column=1, pady=(10,0))

#check if first time log in or not
def hasPassword():
    file_exists = os.path.exists(file_path)
    return file_exists

def main():
    global home
    home = Tk()
    container = ttk.Frame(home, padding=10)
    
    # init container

    # init page A and put the page in the container

    # init page B and put the page in the container

    # to show page A / page B, we use tkraise
    # print(type(Frame()))

    home.geometry('400x250')
    home.title('Log in')
    #check if first time log in or not
    checkPassword = hasPassword()
    if checkPassword == True:
        drawUI()
    else:
        drawFirstTime()
        

    home.mainloop()
main()



